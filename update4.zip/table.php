
<table id="table_temp" class="table table-striped table-hover"> 
	<tr>
		<th style="width: 20%">&nbsp;</th>
		<th style="width: 30%">Product Name</th>
		<th style="width: 20%">Quantity</th>
		<th style="width: 15%">Price</th>
		<th style="width: 15%">&nbsp;</th>
	</tr>
	<tr>
		<th class="text-center" id="totalprice" colspan="5">
			
		</th>
	</tr>
		
</table>
<div>
	<button class=" submit-all btn btn-primary">
		Confirm Order
	</button>
</div>