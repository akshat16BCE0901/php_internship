<div style="background-color: rgba(0,0,0,0.8);color: white" align="center" class="footer row">
	<p class="lead">COPYRIGHT &copy; AKSHAT SINGHAL, 2019</p>
</div>