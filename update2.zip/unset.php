<?php
    session_start();
    unset($_SESSION['randnum']);
    unset($_SESSION['randnum2']);
    unset($_SESSION['user']);
?>